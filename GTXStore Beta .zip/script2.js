document.addEventListener("DOMContentLoaded", function() {
    const registerLink = document.getElementById("register-link");
    const loginForm = document.getElementById("loginForm");
    const registerForm = document.getElementById("registerForm");

    registerLink.addEventListener("click", function(event) {
        event.preventDefault();
        loginForm.style.display = "none";
        registerForm.style.display = "block";
        document.getElementById("form-title").innerText = "Register";
    });
});